import pandas as pd
import tensorflow as tf



def load_and_convert_data_to_df():
    db_path_train = "./smart_dataset/datasets/dbpedia/smarttask_dbpedia_train.json"
    db_path_val ="./smart_dataset/datasets/dbpedia/smarttask_dbpedia_test.json"
    
    db_train_df = pd.read_json(db_path_train)
    db_val_df = pd.read_json(db_path_val)

    db_train_df.dropna(subset=["question","category"], inplace=True)
    db_val_df.dropna(subset=["question","category"], inplace=True)

    print("Details for db Train Dataset: ", db_train_df.shape)
    print("Details for db Validation Dataset: ", db_val_df.shape)
    class_label_names = ['literal', 'boolean', 'resource']
    return db_train_df, db_val_df, class_label_names


def create_train_test_split(db_train_df, db_val_df, model_name):
    X_train = db_train_df[:]["question"]
    y_train = db_train_df[:]["category"]
    X_test = db_val_df[:]["question"]
    y_test = db_val_df[:]["category"]
    print("Train Test split details for {}: \n".format(model_name), X_train.shape, y_train.shape, X_test.shape, y_test.shape)
    return X_train, X_test, y_train, y_test


