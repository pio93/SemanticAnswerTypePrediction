import pandas as pd
import ktrain
from ktrain import text
from MLpipline import roberta
from MLpipline import model as Model
from MLpipline import utils
from MLpipline import feature_engineering

import warnings
warnings.simplefilter(action='ignore')


# Load Train and Validation data and convert to DataFrame Object for further operations:
print('##### Load Train and Validation data and convert to DataFrame Object for further operations #####')
db_train_df, db_val_df, class_label_names = utils.load_and_convert_data_to_df()

# Run for model:
model_name = "roberta"

# Data Preprocessing using K-Train:
print('##### Data Preprocessing using K-Train for RoBERTa #####')
roberta_transformer = roberta.RoBERTa().create_transformer()

X_train, X_test, y_train, y_test = utils.create_train_test_split(db_train_df, db_val_df, model_name)
roberta_train, roberta_val = feature_engineering.perform_data_preprocessing(roberta_transformer, X_train, y_train, X_test, y_test)

# Create & Train RoBERTa Model:
print('##### Create & Train RoBERTa Model #####')
model_learner_ins = Model.create_and_train_model(roberta_train, roberta_val, roberta_transformer, model_name)

# Check Model performance during training and validation:
print('##### Check Model performance during training and validation #####')
Model.check_model_performance(model_learner_ins, class_label_names, model_name)
