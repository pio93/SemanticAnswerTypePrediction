import ktrain
from ktrain import text

# create a function for training roberta model
def create_and_train_model(train, val, transformer_model, model_name):
    model = transformer_model.get_classifier()
    model_learner_ins = None
    model_name == "roberta"
    print("\nCompiling & Training RoBERTa for maxlen=512 & batch_size=6")
    model_learner_ins = ktrain.get_learner(model=model,
                                            train_data=train,
                                            val_data=val,
                                            batch_size=6)
                                               
    print("Model Summary: \n", model_learner_ins.model.summary())
    print("\nFine Tuning RoBERTa on db Dataset with learning rate=3e-5 and epochs=3")
    model_learner_ins.fit_onecycle(lr=3e-5, epochs=3)

    return model_learner_ins


def check_model_performance(model_learner_ins, class_label_names, model_name):
    print("{} Performance Metrics on db Dataset :\n".format(model_name), model_learner_ins.validate())
    print("{} Performance Metrics on db Dataset with Class Names :\n".format(model_name),
          model_learner_ins.validate(class_names=class_label_names))
    return None



